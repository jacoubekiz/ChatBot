# Models are now split into separate subdirectories for better organization
# Import all models from their respective subdirectories
from .Auth.models_auth import CustomUser, Duration, WorkingTime, Calendar, BookAnAppointment
from .Account.models_account import Account, Team
from .Contact.models_contact import Contact, Conversation, ChatMessage, MessageStatus, MediaManagement
from .Flow.models_flow import Flow, Trigger, Chat, Attribute, Custome_attribute, RestartKeyword
from .Channel.models_channel import Channle
from .Campaign.models_campaign import WhatsAppCampaign, AnalyticsCampaign
from .APIs.models_api import Parameter, API, Api_parameter, APILog
from .Messaging.models_messaging import Tag, Group, QuickReply
from .Utility.models_utility import TestWebhook, InternalChat, Report, ChatbotBuilder, Setting, UploadImage
